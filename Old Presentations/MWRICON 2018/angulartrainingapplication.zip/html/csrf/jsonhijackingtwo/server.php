<?php
error_reporting(0);


$cookievalueforcheck = '74b87337454200d4d33f80c4663dc5e5';
if ($cookievalueforcheck !== $_COOKIE["CSRF-TOKEN-JSONHIJACK2"]) {
  print 'CSRF-TOKEN Missing';
  throw new Exception('Token Missing');
} 



header("Content-type: application/json");



$ar = array('tokensecret', '675');
echo json_encode($ar); // ["apple","orange","banana","strawberry"]
/*
$d = array('foo' => 'bar', 'baz' => 'long');

$newarray = json_encode($d);
echo $json = '['.$newarray.']';
*/

?>




