<?php
header("Content-Type:text/plain");

/*
if(!isset($_COOKIE[$cookie_name])) {
     exit("User cookie is not set!");
} 

*/




//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}

/*
if (empty($_SERVER['HTTP_REFERER'])) {
    exit('No Referer'); 
}

if(isset($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']))
if(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST)!=$_SERVER['HTTP_HOST'])
exit('Anti-CSRF mechanism!');  
*/

$cookievalueforcheck = 'f561aaf6ef0bf14d4208bb46a4ccb3ad';
if ($cookievalueforcheck !== $_COOKIE["challengetwo"]) {
  print 'Authentication Cookie Missing';
  throw new Exception('Token Missing');
} 


$request = file_get_contents('php://input');
$input = json_decode($request, true);

if(!is_array($input)){
	throw new Exception('Received content contained invalid JSON!');
	echo 'Request contained invalid JSON!';
}

$cookie = $input['challengeno'];
$value = 'csrfchallenge2';


if ($cookie !== $value) {
	 exit("csrfchallenge2 data array missing");
}



//If json_decode failed, the JSON is invalid.
$data = $input['username'];
echo 'Successfully change password for user '.$data;
return 'Successfully changed password for user '.$data;











