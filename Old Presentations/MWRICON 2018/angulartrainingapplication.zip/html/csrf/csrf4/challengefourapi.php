<?php
header("Content-Type:text/plain");


$cookievalueforcheck = '111b7b7691256a11238a9b6fbcd81c71e';
if ($cookievalueforcheck !== $_COOKIE["challengefour"]) {
  print 'Authentication Cookie Missing';
  throw new Exception('Token Missing');
} 



//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}

/*
if (empty($_SERVER['HTTP_REFERER'])) {
    exit('No Referer'); 
}

if(isset($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']))
if(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST)!=$_SERVER['HTTP_HOST'])
exit('Anti-CSRF mechanism!');  
*/

$request = file_get_contents('php://input');
$input = json_decode($request, true);


if(!is_array($input)){
	throw new Exception('Received content contained invalid JSON!');
	echo 'Request contained invalid JSON!';
}

$contentypecheck = 'application/json';
$allHeaders = getallheaders();
$contentType = $allHeaders['Content-Type'];

if ($contentypecheck !== $contentType) {
  print 'Wrong Content Type sent!';
  throw new Exception('Wrong Content Type sent');
} 




//If json_decode failed, the JSON is invalid.
$data = $input['username'];
echo 'Successfully change password for user '.$data;
return 'Successfully changed password for user '.$data;











