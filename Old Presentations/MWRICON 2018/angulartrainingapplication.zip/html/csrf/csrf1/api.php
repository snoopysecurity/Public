<?php
header("Content-Type:application/plain");

/*
if(!isset($_COOKIE[$cookie_name])) {
     exit("User cookie is not set!");
} 

*/




//Make sure that it is a POST request.
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
    throw new Exception('Request method must be POST!');
}

$cookievalueforcheck = '8c71fb3f7593543f2ad180d31148a7cf';
if ($cookievalueforcheck !== $_COOKIE["challengeone"]) {
  print 'Authentication Cookie Missing';
  throw new Exception('Token Missing');
} 



/*
if (empty($_SERVER['HTTP_REFERER'])) {
    exit('No Referer'); 
}

if(isset($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']))
if(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST)!=$_SERVER['HTTP_HOST'])
exit('Anti-CSRF mechanism!');  
*/

$request = file_get_contents('php://input');
$qt = str_replace("=", "",$request);
$input = json_decode($qt, true);

if(!is_array($input)){
	throw new Exception('Received content contained invalid JSON!');
	echo 'Request contained invalid JSON!';
}

$cookie = $input['challengeno'];
$value = 'csrfchallenge1';


if ($cookie !== $value) {
	 exit("User cookie is not set!");
}



//If json_decode failed, the JSON is invalid.
$data = $input['username'];
echo 'Successfully change password for user '.$data;
return 'Successfully changed password for user '.$data;











