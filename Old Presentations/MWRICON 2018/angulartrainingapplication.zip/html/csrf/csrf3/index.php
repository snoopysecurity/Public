<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Cross-Site Request Forgery Challenge 3</title>
  <!-- Bootstrap core CSS -->
    <link href="../../assets/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../../assets/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../../assets/offcanvas.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/ie-emulation-modes-warning.js"></script>

<?php 
setcookie("color","red");

?>


    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.3.0-beta.1/angular.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.3.0-beta.1/angular-cookies.min.js"></script>
    <meta charset="utf-8">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  
  
  
  <body>
    <nav class="navbar navbar-fixed-top navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/">AngularJS Security Workshop</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div><!-- /.nav-collapse -->
      </div><!-- /.container -->
    </nav><!-- /.navbar -->
    <div class="container">
		

      <div class="row row-offcanvas row-offcanvas-right">

        <div class="col-xs-12 col-sm-9">
          <p class="pull-right visible-xs">
            <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
          </p>
          
<?php
$cookie_name = "challengethree";
$cookie_value = "112b7b7695503a9248a9b6fbcd81c45e";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); 
?>
</head>
<body>
  <h2>Cross-Site Request Forgery Challenge 3</h2>

<p> Your goal is to create a working CSRF Proof of Concept for the following Change Password functionality.</p>
<br>
<p>Having miscofigured cross-domain polcies can allow any third-party domain to perform two-way interaction to the vulnerable domain. While this configuration is not a always considered a vulnerability, it’s only recommended for sites which provide information that is not considered to be sensitive.</p>
<br>


  <h3>User Change Password Functionality</h3>




<script type="text/javascript">
var app = angular.module('postserviceApp', ['ngCookies']);


app.controller('postserviceCtrl', function ($scope, $http) {
	$scope.username = null;
	$scope.password = null;
	$scope.lblMsg = null;
	$scope.postdata = function (username, password) {
	var data = {
username: username,
password: password,
};

app.config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
    }
]);
    
    $scope.postData = function() {
        // Set the Content-Type 
        $http.defaults.headers.post["Content-Type"] = "application/x-www-form-urlencoded";
        // Delete the Requested With Header
        delete $http.defaults.headers.common['X-Requested-With'];
        $httpProvider.defaults.withCredentials = true;
        
        };
//Call the services
$http.post('/challengethreeapi/', JSON.stringify(data)).then(function (response) {
if (response.data)
$scope.msg = "Request sent successfully!";
$scope.PostDataResponse = response.data;
}, function (response) {
$scope.msg = "Service not Exists";
});
};
});
</script>

	
<div ng-app="postserviceApp" ng-controller="postserviceCtrl">
<div>
Username : <input ng-model="username" /><br/><br/>
Password : <input ng-model="password" /><br/><br/>
<input type="button" value="Send" ng-click="postdata(username, password)" /> <br/><br/>
</div>
<p>Output Message : {{msg}} </p>
{{ PostDataResponse }}
</div>


</body>
</html>


