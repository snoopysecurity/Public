<?php
header("Content-Type:text/plain");
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']) && $_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'] == 'POST') {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
		header('Access-Control-Allow-Credentials: true');
		header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
        header("Access-Control-Allow-Headers: origin, x-requested-with, content-type, securityToken");
    }
    exit;
}

$cookievalueforcheck = '112b7b7695503a9248a9b6fbcd81c45e';
if ($cookievalueforcheck !== $_COOKIE["challengethree"]) {
  print 'Authentication Token Missing';
  throw new Exception('Token Missing');
} 




$request = file_get_contents('php://input');
$input = json_decode($request, true);

if(!is_array($input)){
	throw new Exception('Received content contained invalid JSON!');
	echo 'Request contained invalid JSON!';
}

if (isset($_SERVER['HTTP_ORIGIN'])) {
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
  $data = $input['username'];
  echo 'Successfully change password for user '.$data;

} else {
  header('Access-Control-Allow-Origin: *');
  header('Access-Control-Allow-Credentials: true');
//  echo 'No Origin header set';
}



$cookie = $input['usersessiontoken'];
$value = 'csrfchallenge3';

/*
if ($cookie !== $value) {
	 exit("User cookie is not set!");
}
*/


//If json_decode failed, the JSON is invalid.




?>
