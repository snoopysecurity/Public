<?php
error_reporting(0);


header("Content-type: application/json");


$cookievalueforcheck = '206f8d0f7e705c6e401c5dd267e40aea';
if ($cookievalueforcheck !== $_COOKIE["jsonhijackingone"]) {
  print 'Token Missing';
  throw new Exception('Token Missing');
} 



$json = '[{"secrettoken":"'.md5(uniqid(rand(), true)).'","customername":"Sam"}]';

echo $json;





