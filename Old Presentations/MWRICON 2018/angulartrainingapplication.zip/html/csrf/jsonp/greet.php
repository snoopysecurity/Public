<?php
error_reporting(0);
$name = $_GET['action'];
$callback = $_GET['callback'];
$pattern = '/^[\\w\\._\\d]+$/';
if (!preg_match($pattern, $callback)) {
  exit('invalid callback');
}
$name = array(
    "Sam",
    "Dave",
    "Joe",
    "Rob",
    "Bob",
    "Mike",
    "Terry",
    "Wu",
    "Grant",
    "Dante",
    "Slyvia",
    "Hayley",
    "Tesla",
    "John",
    "Haye",
    "Niall",
    "Hej",
    "James",
    "Mark" );
$token = md5(uniqid(rand(), true));
$greeting = "user names and secret accesstoken";
$data = array(
  "greeting" => $greeting,
  "customernames" => $name,
  "secretaccesstoken" => $token);
$json = json_encode($data);
header("Content-type: text/javascript");
if ($callback)
  echo $callback .' (' . $json . ');';
else
  echo $json;
?>
