<?php 



$request = file_get_contents('php://input');
$input = json_decode($request, true);

if(!is_array($input)){
	throw new Exception('Received content contained invalid JSON!');
	echo 'Request contained invalid JSON!';
}

$data = $input['Name'];
echo $data;
return $data;


