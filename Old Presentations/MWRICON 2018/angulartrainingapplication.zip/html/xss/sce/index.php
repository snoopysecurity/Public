<!DOCTYPE html>

    <head>
        <title>Unsafe use of ngBindHtml</title>
        <meta charset="utf-8">
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.6/angular.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.6/angular-sanitize.js"></script>
    </head>
<body>



<div ng-app="MyApp" ng-controller="view1Ctrl"> 
 <form>
      <input type="text" ng-model="formData.Name" placeholder="Enter Name" />
      <button type="submit" class="btn btn-primary" ng-click="ButtonClick()">Submit</button>
</form>
	<br>
	<p><b>Today's welcome message is:</b><div ng-bind-html="myWelcome | to_trusted"></div>
</div>


<script>

var app = angular.module('MyApp', ['ngSanitize']);
app.controller('view1Ctrl', function($scope, $http) {
    $scope.ButtonClick = function() {
        $http.post('/xss/server.php',$scope.formData).then(function(response){
        $scope.myWelcome = response.data;
      
        })
    }
});

function view1Ctrl($scope) {
    $scope.myWelcome = response.data;
}

angular.module('MyApp')
    .filter('to_trusted', ['$sce', function($sce){
        return function(text) {
            return $sce.trustAsHtml(text);
        };
    }]);


</script>
          
    </div>
  </div>


</body>
</html>
