<!DOCTYPE html>

    <head>
        <title>Unsafe use of ngBindHtml</title>
        <meta charset="utf-8">
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.6/angular.js"></script>

    </head>
    <body>


	<div ng-app="myApp" ng-controller="view1Ctrl"> 

	<br>

<form>
      <input type="text" ng-model="formData.desc" placeholder="Enter Welcome Message" />
      <button type="submit" class="btn btn-primary" ng-click="sub()">Submit</button>
</form>
<div ng-app="myApp" ng-controller="view1Ctrl">
	<br>
	<p>Today's welcome message is:<div ng-bind-html="myWelcome | to_trusted"></div>
</div>


<script>

var app = angular.module('myApp', []);
app.controller('view1Ctrl', function($scope, $http) {
    $scope.sub = function() {
        $http.post('/view1',$scope.formData).then(function(response){
        $scope.myWelcome = response.data;
      
        })
    }
});

function view1Ctrl($scope) {
    $scope.myWelcome = response.data;
}

angular.module('myApp')
    .filter('to_trusted', ['$sce', function($sce){
        return function(text) {
            return $sce.trustAsHtml(text);
        };
    }]);


</script>
          
    </div>
  </div>


</body>
</html>
